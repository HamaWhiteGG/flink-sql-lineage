import Hive from './icon-task/Hive.svg'
import Hive2 from './icon-task/Hive2.svg'
import Mysql from './icon-task/Mysql.svg'
import Default from './icon-task/default.svg'


export default {
  Hive,
  Hive2,
  Mysql,
  Default,
}
