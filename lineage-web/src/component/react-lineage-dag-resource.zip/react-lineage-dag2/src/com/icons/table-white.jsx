import React from 'react'
import {Tooltip} from 'antd'
import Icon from '@ant-design/icons'
import TableIcon from './table-white-icon.svg'

const TableWhite = ({mappingTable}) => {
  return (
    <Tooltip 
      title={`${!!mappingTable ? '映射' : ''}表`}
    >
      <span className="icon-table">
        <img alt="" src={TableIcon} />
      </span>
    </Tooltip>
  );
};

export default TableWhite;
