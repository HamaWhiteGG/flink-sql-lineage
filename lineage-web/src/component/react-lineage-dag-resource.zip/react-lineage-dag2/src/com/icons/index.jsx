import {Table, Api, Application, Label} from './table'
import TableWhite from './table-white'
import Column from './column'
import './index.less'

export default {
  Table,
  TableWhite,
  Column,
  Api, 
  Application, 
  Label,
}
