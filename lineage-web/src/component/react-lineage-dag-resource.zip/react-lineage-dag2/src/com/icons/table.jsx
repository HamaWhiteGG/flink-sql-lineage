import React from 'react'
import {Tooltip} from 'antd'
import Icon from '@ant-design/icons'
import TableIcon from './table-icon.svg'
import ApiIcon from './api-icon.svg'
import ApplicationIcon from './application-icon.svg'
import LabelIcon from './label-icon.svg'

export const Table = ({tableIcon, mappingTable}) => {
  return (
    <Tooltip 
      title={`${!!mappingTable ? '映射' : ''}表`}
    >
      <span className="icon-table">
        <img alt="" src={tableIcon} />
      </span>
    </Tooltip>
  )
}

export const Api = () => {
  return (
    <Tooltip 
      title="Api"
    >
      <span className="icon-table">
        <img alt="" src={ApiIcon} />
      </span>
    </Tooltip>
  )
}

export const Application = () => {
  return (
    <Tooltip 
      title="应用"
    >
      <span className="icon-table">
        <img alt="" src={ApplicationIcon} />
      </span>
    </Tooltip>
  )
}

export const Label = () => {
  return (
    <Tooltip 
      title="标签"
    >
      <span className="icon-table">
        <img alt="" src={LabelIcon} />
      </span>
    </Tooltip>
  )
}
