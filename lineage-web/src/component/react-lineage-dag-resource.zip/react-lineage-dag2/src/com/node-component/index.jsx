import React, {useState} from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import {Tooltip, message} from 'antd';

import Icons from '../icons';
import {Endpoint} from 'butterfly-react';
import {NodeTypes} from '../../util/props';

import './index.less';
import Icon from '@ant-design/icons';

const noop = () => null;

/**
 * 获取一个锚点
 * @param {String} nodeId 节点的ID
 * @param {String} id 唯一ID
 * @param {String} direction 方向
 * @param {Boolean} visible 是否可见
 * @param {Boolean} isUpExpand 上游是否可展开
 */
const getEndpoint = (
  nodeId, id,
  direction, visible = false,
  endpointClassName = '',
  onEndpointClick = noop,
  isUpExpand = false,
) => {
  return (
    <span
      className={classnames(
        'item-endpoint',
        `item-endpoint-${direction}`,
        {visible},
        `${endpointClassName}`,
      )}
      onClick={() => visible && onEndpointClick(nodeId, direction)}
    >
      <Endpoint
        nodeId={nodeId}
        id={id + `-${direction}`}
        orientation={direction === 'left' ? [-1, 0] : [1, 0]}
      />
    </span>
  );
};


const NodeComponent = props => {
  const {
    node,
    onItemActive,
    activeNodeItemIds = [],
    isHidden = false,
    onNodeClick = noop,
    onItemClick = noop,
    onNodeDoubleClick = noop,
    endpointEdge = {},
    isUnRelItemHidden = false,
    onNodeItemDoubleClick = noop,
    onEndpointClick = noop,
    isLoop = false,
    loopNum = 0,
  } = props
  const typeObj = {
    // 1: <Icons.Application />,
    2: <div className="white-bg">
    <Icons.Table tableIcon={node.tableIcon} mappingTable={node.mappingTable} />
    </div>,
    3: <Icons.Api />,
    4: <Icons.Application />,
    5: <Icons.Label />,
  }
  const colorObj = {
    2: '#E6F6FF', // 表
    3: '#EFFBEC', // api
    4: '#F7F5FF', // 应用
    5: '#FFF8EA', // 标签
  }
  const {
    nodeItems, title, id, type,
    operators = [],
    isHideEndpoint = false,
    endpointClassName = '',
    nodeClassName = '',
    isPrimary = false,
    nodeIcon = typeObj[type],
    isLoopActive = false, // 环路是否高亮
    isFold,
    isUpExpand, // 上游是否展开
    isDownExpand, // 下游是否展开
    scopeType,
    DownIsTable, // 下游节点是否为表，是： true，
    mappingTable, // 当前节点是否为映射表
  } = node;
  console.log('isFold---', isFold, (!!isFold && isDownExpand) || type !== 2)

  const isTableActive = activeNodeItemIds.includes(id)
  const leftClassName = !isLoop ? (
    loopNum === 0 ? (
      isUpExpand && (scopeType === '1' || scopeType === '3') ? 'left21' : '' 
    ) : ''
  ) : ''

  return (
    <div
      className={`component ${nodeClassName}`}
      key={id}
    >
      <div
        // className={
        //   !isLoopActive ? 
        //   (isPrimary ? "field primay-table" : "field" ) 
        //   : 
        //   (isPrimary ? "field primay-table loop-active" : "field loop-active" )
        // }
        className={`${!!mappingTable ? "dashed" : ""} ${!isLoopActive ? 
          (isPrimary ? "field primay-table" : "field" ) 
          : 
          (isPrimary ? "field primay-table loop-active" : "field loop-active" )
          }`
        }
        onClick={() => {

        }}
      >
        <div
          className={`field-title field-item ${isTableActive ? 'field-item-active' : ''}`}
          style={{backgroundColor: colorObj[type]}}
          onClick={e => {
            if (!isLoop && loopNum === 0) {
              e.stopPropagation()

              onNodeClick(id)
            } else if (!isLoop) {
              message.warning(`当前血缘存在${loopNum}条环路，不支持血缘高亮，请开启血缘环路进行检测！`)
            }
          }}
          onDoubleClick={() => onNodeDoubleClick(id)}
        >
          {
            <div className="node-icon">{nodeIcon}</div>
          }
          <div className="filed-title-name">
            <Tooltip title={title}>
              {title}
            </Tooltip>
          </div>
          {/* {
            !DownIsTable ? 
              getEndpoint(id, id, 'right', isHideEndpoint, endpointClassName, onEndpointClick, isUpExpand) 
            : 
            null
          } */}
          {(!!isFold) ? getEndpoint(id, id, 'right', isHideEndpoint, endpointClassName, onEndpointClick, isUpExpand) : null}

          {(!!isFold) ? getEndpoint(id, id, 'left', isHideEndpoint, leftClassName, onEndpointClick, isUpExpand) : null}
          
          {/* {(isDownExpand) || !DownIsTable ? getEndpoint(id, id, 'right', isHideEndpoint, endpointClassName, onEndpointClick, isUpExpand) : null}

          {(isUpExpand) || type !== 2 ? getEndpoint(id, id, 'left', isHideEndpoint, leftClassName, onEndpointClick, isUpExpand) : null}
           */}
          <div className="operators">
            {
              operators.map(({component}, index) => {
                return (
                  <span className="op-item" key={index}>
                    {component}
                  </span>
                );
              })
            }
          </div>
        </div>
        <div className={!isHidden && nodeItems.length > 0 ? "field-content" : ""}>
          {
            !isHidden && nodeItems.map(nodeItem => {
              const {icon = <Icons.Column />} = nodeItem;
              const isActive = activeNodeItemIds.includes(nodeItem.id) || nodeItem.isActive;

              // 是否有链接
              // const hasConnect = endpointEdge[`${nodeItem.id}-left`] || endpointEdge[`${nodeItem.id}-right`];

              // if (isUnRelItemHidden && !hasConnect) {
              //   return null;
              // }

              return (
                <div
                  className={
                    classnames('field-item', {
                      'field-item-active': isActive,
                    })
                  }
                  key={nodeItem.id}
                  onMouseEnter={() => {
                    if (!isLoop && loopNum === 0) {
                      onItemActive(nodeItem.id)
                    }
                  }}
                  // onMouseLeave={() => {
                  //   onItemActive()
                  // }}
                  onClick={(e) => {
                    e.stopPropagation()
                    // 获取详情
                    onItemClick(nodeItem)
                    if (!isLoop && loopNum === 0) {
                      // 获取血缘
                      onItemActive(nodeItem.id)
                    }
                  }}
                  onDoubleClick={() => onNodeItemDoubleClick(nodeItem.id)}
                >
                  {getEndpoint(id, nodeItem.id, 'left', endpointEdge[`${nodeItem.id}-left`] || nodeItem.isHideEndpoint, endpointClassName, onEndpointClick)}
                  {getEndpoint(id, nodeItem.id, 'right', endpointEdge[`${nodeItem.id}-right`] || nodeItem.isHideEndpoint, endpointClassName, onEndpointClick)}
                  <div
                    className="field-item-content"
                  >
                    <div
                      className="field-item-title"
                    >
                      <div className="item-text">
                        <div style={{flex: 2}}><span className="name">{nodeItem.name}</span></div>
                        <div className="desc omit" title={nodeItem.childrenCnt || '-'}>
                          <Tooltip title='Downstream total'>
                            <div className='circle-text'>
                              {nodeItem.childrenCnt || <span className="gray">-</span>}
                            </div>
                          </Tooltip>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          }
        </div>
      </div>
    </div>
  );
};

NodeComponent.propTypes = {
  node: NodeTypes,
  onItemActive: PropTypes.func,                             // 节点hover时
  activeNodeItemIds: PropTypes.arrayOf(PropTypes.string),   // 当前active的节点，用于判断是否应该高亮
  isHidden: PropTypes.bool,                                 // 是否收起字段
  onNodeClick: PropTypes.func,                              // 节点点击时
  onItemClick: PropTypes.func,                              // 字段点击时
  onNodeDoubleClick: PropTypes.func,                        // 节点双击是
  onNodeItemDoubleClick: PropTypes.func,                    // 字段双击
  isActive: PropTypes.bool,                                 // 字段是否高亮
  isNodeActive: PropTypes.bool,                             // 血缘环路中，节点是否高亮
  endpointEdge: PropTypes.object,                           // 边和锚点的映射，渲染用
  isUnRelItemHidden: PropTypes.bool,                        // 是否隐藏没有联系的列
  onEndpointClick: PropTypes.func,                          // 锚点单击事件
  isLoop: PropTypes.bool,                                   // 是否是血缘环路
};

export default NodeComponent;


