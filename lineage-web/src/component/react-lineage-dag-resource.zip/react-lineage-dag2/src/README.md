# 血缘基础组件
![](https://duing.alibaba-inc.com/img/label?keyBgColor=f66901&key=Project&value=DataQ)

## 功能描述
<!-- 这里写一段简单的描述，写一下你的组件/物料功能 -->    

    
## Demo
<!-- Demo为可选项，放riddle或一张图片 -->

    
## 安装
```bash
$ tnpm i @ali/lineage-dag -S
```

    
## 使用
<!-- 简单代码介绍如何写代码 -->
```jsx
  import LineageDAG from '@ali/lineage-dag';
```


## API
<!-- 一张表格介绍你的Props属性 -->


## 开发 & 构建
