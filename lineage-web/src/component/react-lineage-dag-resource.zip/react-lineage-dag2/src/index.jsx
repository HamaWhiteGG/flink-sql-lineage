import LineageDag from './lineage';
import Table from './table';

export default LineageDag;
export const LineageTable = Table;
