import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import {Tooltip} from 'antd'
import calcPath from './calc_path';
import {NodeTypes, EdgeTypes} from './props';
import NodeComponent from '../com/node-component';
import Task from '../com/icons/icon-task'
const noop = () => null;

// 任务图标base64，页面各模块公用
// const reqIcon = require.context('../com/icons/icon-task')
// const icon = {}
// reqIcon.keys().map(item => {
//   icon[item.split('.')[1].slice(1)] = reqIcon(item)
//   return item
// })
// // perl类型支持大小写敏感，而操作系统文件类型大小写不敏感，所以需要复制一份
// if (icon.Perl) {
//   icon.perl = icon.Perl
// }
// export const iconBase64 = icon

/**
 * 获取锚点和edge的映射
 * @param {EdgeTypes[]} edges
 */
const getEpEdgeMap = (edges) => {
  const map = {};
  for (let edge of edges) {
    const {srcNodeItemId, tgtNodeItemId} = edge;

    map[`${srcNodeItemId}-right`] = true;
    map[`${tgtNodeItemId}-left`] = true;
  }

  return map;
};

/**
 * 从用户传入的数据转换为butterfly-react支持的数据格式
 * @param {NodeTypes} nodes 用户节点
 * @param {String} string activeItemId
 * @return {INode} ref: https://github.com/alibaba/butterfly/blob/master/docs/zh-CN/react.md#%E5%B1%9E%E6%80%A7
 */
export const toNodes = ({
  nodes,
  activeNodeItemIds = [],
  onItemActive = noop,
  onNodeClick = noop,
  onItemClick = noop,
  onNodeDoubleClick = noop,
  onNodeItemDoubleClick = noop,
  edges = [],
  onEndpointClick = noop,
  isLoop = false,
  endpointClassName = '',
  loopNum = 0,
}) => {
  if (!nodes || nodes.length === 0) {
    return [];
  }

  const btfNodes = [];
  const epEdgeMap = getEpEdgeMap(edges);
  PropTypes.checkPropTypes(NodeTypes, nodes[0]);
  nodes.forEach(node => {
    const {nodeItems, id: _id} = node;
    let id = _id;
    if (!id) {
      id = nodeItems[0].info.id;
    }

    // if (!nodeItems || nodeItems.length === 0) {
    //   return;
    // }
    btfNodes.push({
      id: id,
      render() {
        return (
          <NodeComponent
            node={node}
            isUnRelItemHidden={node.isUnRelItemHidden}
            onMouseMethod={this.onMouseMethod}
            onDoubleClick={this.onNodeDoubleClick}
            activeNodeItemIds={activeNodeItemIds}
            onItemActive={onItemActive}
            isHidden={node.isHide}
            onNodeClick={onNodeClick}
            onNodeDoubleClick={onNodeDoubleClick}
            onNodeItemDoubleClick={onNodeItemDoubleClick}
            endpointEdge={epEdgeMap}
            onEndpointClick={onEndpointClick}
            isLoop={isLoop}
            loopNum={loopNum}
            endpointClassName={endpointClassName}
            onItemClick={onItemClick}
          />
        );
      },
    });
  });

  return btfNodes;
};

/**
 * 得到item和node的映射
 * @param {NodeTypes} nodes 用户节点
 */
const getItemIdMap = (nodes) => {
  if (!nodes) {
    return {};
  }

  const map = {};

  for (let node of nodes) {
    const {id, nodeItems} = node;

    // if (!nodeItems || nodeItems.length === 0) {
    //   continue;
    // }
    
    for (let item of nodeItems) {
      map[item.id] = id;
    }
    
    // if(nodeItems.length === 0) {
      map[id] = id;
    // }
  }

  return map;
};

const getNodeIdMap = (nodes) => {
  const nodeIdMap = {};

  for (let node of nodes) {
    nodeIdMap[node.id] = node;
  }

  return nodeIdMap;
};

/**
 * 将用户传入的节点属性转换为ButterflyReact可识别的类型
 * @param {EdgeTypes} edges 用户边
 * @param {NodeTypes} nodes 用户节点
 * @param {String} id 当前active的item的id
 * @return {IEdge} ref: https://github.com/alibaba/butterfly/blob/master/docs/zh-CN/react.md#%E5%B1%9E%E6%80%A7
 */
export const toEdges = ({
  edges,
  nodes,
  activeEdgeIds = [],
}) => {
  if (!edges || edges.length === 0) {
    return [];
  }

  const btfEdges = [];
  const itemNodeMap = getItemIdMap(nodes);
  const nodeIdMap = getNodeIdMap(nodes);
  PropTypes.checkPropTypes(EdgeTypes, edges[0]);
  edges.forEach(edge => {
    let {srcNodeItemId, tgtNodeItemId, isHide} = edge;
    const sourceNodeId = itemNodeMap[srcNodeItemId];
    const targetNodeId = itemNodeMap[tgtNodeItemId];
    if (!edge.id) {
      edge.id = `${srcNodeItemId}@@${tgtNodeItemId}`;
    }

    const sourceNode = nodeIdMap[sourceNodeId];
    const targetNode = nodeIdMap[targetNodeId];
    if (!targetNodeId || !sourceNodeId) {
      // console.warn(`边(${srcNodeItemId}->${targetNodeId})找不到对应节点，无法渲染！`);
      return;
    }
    // 隐藏的节点将线直接连到节点上
    if (sourceNode.isHide && targetNode.type === 2) {
      srcNodeItemId = sourceNodeId;
    }

    if (targetNode.isHide && targetNode.type === 2) {
      tgtNodeItemId = targetNodeId;
    }

    let isActive = activeEdgeIds.includes(edge.id) || edge.isActive;
    

    const edgeItem = {
      id: srcNodeItemId + tgtNodeItemId,
      sourceNode: sourceNodeId,
      targetNode: targetNodeId,
      source: srcNodeItemId + '-right',
      target: tgtNodeItemId + '-left',
      isActive,
      type: 'endpoint',
      // calcPath,
      shapeType: 'AdvancedBezier',
      className: classnames({
        'lineage-edge-un': !!edge.mappingLink,
        'lineage-edge-hover-active': isActive,
        'lineage-edge-content': !!isActive,
        // 'lineage-edge-hide': isHide,

        'lineage-edge-loop-active': edge.isLoopActive,
      }),
      labelRender() {
        // const imgUrl = !!edge?.task?.specificType ? (!!Task[edge?.task?.specificType] ? Task[edge?.task?.specificType] : Task.Default) : ''
       
        const imgUrl = !!edge?.task ? (!!edge?.task?.taskIcon ? edge?.task?.taskIcon : Task.Default) : null
        // taskType: 1-离线，2-运维，3-实时
        // platform: 1-离线，2-实时
        const platFormMap = {
          1: `/operation/index.html#/offline-task?taskId=${edge?.task?.taskId}&workspaceId=${edge?.task?.workspaceId}`,
          2: `/scheduler/index.html#/stream?taskId=${edge?.task?.taskId}&workspaceId=${edge?.task?.workspaceId}`,
        }
        const urlMap = {
          1: '/batch/index.html#/dipper/task',
          2: platFormMap[edge?.task?.platform],
          3: '/stream/index.html#/dipper/task',
        }
        const Href = urlMap[edge?.task?.taskType]
        // const Href = edge?.task?.taskType == 1 ? '/batch/index.html#/dipper/task' : `/operation/index.html#/offline-task?taskId=${edge?.task?.taskId}`
        const isItemEdge = !!edge.u || !!edge.v

        if ((isActive || !isItemEdge) && imgUrl) {
          return <Tooltip title={edge?.task?.taskName}>
            <span
              onClick={() => {
                localStorage.setItem(`${window.location.origin}_projectId`, edge?.task?.taskProjectId)
                window.open(Href, '_blank')
              }}
             className={`task-icon ${isActive ? 'active':''} ${edge.isLoopActive ? 'loop-active' : ''}`}>
               <img src={imgUrl} width={14} height={14}/>
            </span>
          </Tooltip>
        }
      },
      labelOffset: 20,
    };
    btfEdges.push(edgeItem)
  });
  return btfEdges;
};

/**
 * 字段血缘算出所有被激活的边和点
 * @param {NodeTypes[]} nodes
 * @param {NodeTypes[]} edges
 * @param {String} activeItemId
 */
export const getActiveThings = ({
  edges, nodes, activeItemId
}) => {
  const activeNodeItemIds = [activeItemId];
  const activeEdgeIds = [];

  if (!activeItemId) {
    return {
      activeNodeItemIds: [],
      activeEdgeIds
    };
  }
  
  const findBefore = (activeId) => {
    for (let edge of edges) {
      if (edge.tgtNodeItemId === activeId) {
        const curNode = nodes.filter(n => n.id === edge.relU)[0]
        if (curNode.isHide) {
          if (activeNodeItemIds.findIndex(t => t === edge.relU) === -1 && activeNodeItemIds.findIndex(t => t === edge.srcNodeItemId) === -1 ) {
            activeNodeItemIds.push(edge.relU);
            activeNodeItemIds.push(edge.srcNodeItemId);
            activeEdgeIds.push(edge.id);
            findBefore(edge.relU);
            findBefore(edge.srcNodeItemId);
          }
        } else {
          if (activeNodeItemIds.findIndex(t => t === edge.srcNodeItemId) === -1) {
            activeNodeItemIds.push(edge.srcNodeItemId);
            activeEdgeIds.push(edge.id);
            findBefore(edge.srcNodeItemId);
          }
        }
        
      }
    }
  };
  const findAfter = (activeId) => {
    for (let edge of edges) {
      if (edge.srcNodeItemId === activeId) {
        const curNode = nodes.filter(n => n.id === edge.relV)[0]
        if (curNode.isHide) {
          // 折叠
          if (activeNodeItemIds.findIndex(t => t === edge.relV) === -1 && activeNodeItemIds.findIndex(t => t === edge.tgtNodeItemId) === -1) {
            activeNodeItemIds.push(edge.relV);
            activeNodeItemIds.push(edge.tgtNodeItemId);
            activeEdgeIds.push(edge.id);
            findAfter(edge.relV);
            findAfter(edge.tgtNodeItemId);
          }
        } else {
          // 展开
          if (activeNodeItemIds.findIndex(t => t === edge.tgtNodeItemId) === -1) {
            activeNodeItemIds.push(edge.tgtNodeItemId);      
            activeEdgeIds.push(edge.id);
            findAfter(edge.tgtNodeItemId);
          }
        }
      }
    }
  };

  findBefore(activeItemId);
  findAfter(activeItemId);

  return {
    activeNodeItemIds,
    activeEdgeIds
  };
};


/**
 * 将用户传入的节点属性转换为ButterflyReact可识别的类型
 * @param {EdgeTypes} edges 用户边
 * @param {NodeTypes} nodes 用户节点
 * @param {String} id 当前active的item的id
 * @return {IEdge} ref: https://github.com/alibaba/butterfly/blob/master/docs/zh-CN/react.md#%E5%B1%9E%E6%80%A7
 */
 export const toEdgesItem = ({
  edges,
  nodes,
  activeEdgeIds = [],
}) => {
  if (!edges || edges.length === 0) {
    return [];
  }

  const btfEdges = [];
  const itemNodeMap = getItemIdMap(nodes);
  const nodeIdMap = getNodeIdMap(nodes);
  PropTypes.checkPropTypes(EdgeTypes, edges[0]);
  edges.forEach(edge => {

    let {srcNodeItemId, tgtNodeItemId, isHide} = edge;
    const sourceNodeId = itemNodeMap[srcNodeItemId];
    const targetNodeId = itemNodeMap[tgtNodeItemId];
    if (!edge.id) {
      edge.id = `${srcNodeItemId}@@${tgtNodeItemId}`;
    }

    const sourceNode = nodeIdMap[sourceNodeId];
    const targetNode = nodeIdMap[targetNodeId];

    if (!targetNodeId || !sourceNodeId) {
      // console.warn(`边(${srcNodeItemId}->${targetNodeId})找不到对应节点，无法渲染！`);
      return;
    }

    // 隐藏的节点将线直接连到节点上
    if (sourceNode.isHide) {
      srcNodeItemId = sourceNodeId;
    }

    if (targetNode.isHide) {
      tgtNodeItemId = targetNodeId;
    }


    let isActive = activeEdgeIds.includes(edge.id) || edge.isActive;
    
    const edgeItem = {
      id: srcNodeItemId + tgtNodeItemId,
      sourceNode: sourceNodeId,
      targetNode: targetNodeId,
      source: srcNodeItemId + '-right',
      target: tgtNodeItemId + '-left',
      isActive,
      type: 'endpoint',
      // calcPath,
      shapeType: 'AdvancedBezier',
      className: classnames({
        'lineage-edge-un': !!edge.mappingLink,
        'lineage-edge-hover-active': isActive,
        'lineage-edge-content': !!isActive,
        // 'lineage-edge-hide': isHide,
      }),
      // labelRender: () => null
      labelRender: () => {
        // const imgUrl = !!edge?.task?.specificType ? (!!Task[edge?.task?.specificType] ? Task[edge?.task?.specificType] : Task.Default) : ''
        const imgUrl = !!edge?.task ? (!!edge?.task?.taskIcon ? edge?.task?.taskIcon : Task.Default) : null

        // taskType: 1-离线，2-运维，3-实时
        // platform: 1-离线，2-实时
        const platFormMap = {
          1: `/operation/index.html#/offline-task?taskId=${edge?.task?.taskId}&workspaceId=${edge?.task?.workspaceId}`,
          2: `/scheduler/index.html#/stream?taskId=${edge?.task?.taskId}&workspaceId=${edge?.task?.workspaceId}`,
        }
        const urlMap = {
          1: '/batch/index.html#/dipper/task',
          2: platFormMap[edge?.task?.platform],
          3: '/stream/index.html#/dipper/task',
        }
        const Href = urlMap[edge?.task?.taskType]
        // const Href = edge?.task?.taskType == 1 ? '/batch/index.html#/dipper/task' : `/operation/index.html#/offline-task?taskId=${edge?.task?.taskId}`
        const isItemEdge = !!edge.u || !!edge.v

        if ((isActive || !isItemEdge) && imgUrl) {
          return <Tooltip title={edge?.task?.taskName}>
            <a 
              href={Href} 
              target="_blank" 
              className={`task-icon ${isActive ? 'active':''} ${edge.isLoopActive ? 'loop-active' : ''}`}
            >
              <img src={imgUrl} width={14} height={14} />
            </a>
          </Tooltip>
        }
      },
      labelOffset: 20,
    };

    btfEdges.push(edgeItem);
  });
  return btfEdges;
};

/**
 * 从用户传入的数据转换为butterfly-react支持的数据格式
 * @param {NodeTypes} nodes 用户节点
 * @param {String} string activeItemId
 * @return {INode} ref: https://github.com/alibaba/butterfly/blob/master/docs/zh-CN/react.md#%E5%B1%9E%E6%80%A7
 */
 export const toNodesItem = ({
  nodes,
  activeNodeItemIds = [],
  onItemActive = noop,
  onNodeClick = noop,
  onItemClick = noop,
  onNodeDoubleClick = noop,
  onNodeItemDoubleClick = noop,
  edges = [],
  onEndpointClick = noop,
}) => {
  if (!nodes || nodes.length === 0) {
    return [];
  }

  const btfNodes = [];
  const epEdgeMap = getEpEdgeMap(edges);
  PropTypes.checkPropTypes(NodeTypes, nodes[0]);
  nodes.forEach(node => {
    const {nodeItems, id: _id} = node;
    let id = _id;
    if (!id) {
      id = nodeItems[0].info.id;
    }

    // if (!nodeItems || nodeItems.length === 0) {
    //   return;
    // }

    btfNodes.push({
      id: id,
      render() {
        return (
          <NodeComponent
            node={node}
            isUnRelItemHidden={node.isUnRelItemHidden}
            onMouseMethod={this.onMouseMethod}
            onDoubleClick={this.onNodeDoubleClick}
            activeNodeItemIds={activeNodeItemIds}
            onItemActive={onItemActive}
            isHidden={node.isHide}
            onNodeClick={onNodeClick}
            onItemClick={onItemClick}
            onNodeDoubleClick={onNodeDoubleClick}
            onNodeItemDoubleClick={onNodeItemDoubleClick}
            endpointEdge={epEdgeMap}
            onEndpointClick={onEndpointClick}
          />
        );
      },
    });
  });

  return btfNodes;
};

/**
 * 表血缘算出所有被激活的边和点
 * @param {NodeTypes[]} nodes
 * @param {NodeTypes[]} edges
 * @param {String} activeItemId
 */
 export const getItemActiveThings = ({
  edges, nodes, activeItemId
}) => {
  const activeNodeItemIds = [activeItemId];
  const activeEdgeIds = [];
  const arry = edges.filter(t =>t.relU === activeItemId || t.relV === activeItemId)
  arry.forEach(t => {
    // 下游
    if (t.relU === activeItemId) {
      activeNodeItemIds.push(t.srcNodeItemId)
    }
    // 上游
    if (t.relV === activeItemId) {
      activeNodeItemIds.push(t.tgtNodeItemId)
    }
  })
  if (!activeItemId) {
    return {
      activeNodeItemIds: [],
      activeEdgeIds
    };
  }

  const findBefore = (activeId) => {
    for (let edge of edges) {
      if (edge.tgtNodeItemId === activeId) {
        activeEdgeIds.push(edge.id);
        const curNode = nodes.filter(n => n.id === edge.relU)[0]
        if(curNode.isHide) {
          if (activeNodeItemIds.findIndex(t => t === edge.relU) === -1) {
            activeNodeItemIds.push(edge.relU);
            findBefore(edge.relU);
          }
        }else {
          if (activeNodeItemIds.findIndex(t => t === edge.srcNodeItemId) === -1) {
            activeNodeItemIds.push(edge.srcNodeItemId);
            findBefore(edge.srcNodeItemId);
          }
        }
      }
      if ((edge.relV && edge.relV ===activeId)) {
        activeEdgeIds.push(edge.id);
        // 获取当前节点
        const curNode = nodes.filter(n => n.id === edge.relU)[0]
        if(curNode.isHide) {
          if (activeNodeItemIds.findIndex(t => t === edge.relU) === -1) {
            activeNodeItemIds.push(edge.relU);
            findBefore(edge.relU);
          }
        } else {
          if (activeNodeItemIds.findIndex(t => t === edge.srcNodeItemId) === -1) {
            activeNodeItemIds.push(edge.srcNodeItemId);
            findBefore(edge.srcNodeItemId);
          }
        }
      }
    }
  };

  const findAfter = (activeId) => {
    for (let edge of edges) {
      if (edge.srcNodeItemId === activeId) {
        activeEdgeIds.push(edge.id);
        const curNode = nodes.filter(n => n.id === edge.relU)[0]
        if(curNode.isHide) {
          if (activeNodeItemIds.findIndex(t => t === edge.relV) === -1) {
            activeNodeItemIds.push(edge.relV);
            findAfter(edge.relV);
          }
        } else {
          if (activeNodeItemIds.findIndex(t => t === edge.tgtNodeItemId) === -1) {
            activeNodeItemIds.push(edge.tgtNodeItemId);
            findAfter(edge.tgtNodeItemId);
          }
        }
      }

      if (edge.relU && edge.relU ===activeId) {
        activeEdgeIds.push(edge.id);
        // 获取当前节点
        const curNode = nodes.filter(n => n.id === edge.relV)[0]
        if(curNode.isHide) {
          if (activeNodeItemIds.findIndex(t => t === edge.relV) === -1) {
            activeNodeItemIds.push(edge.relV);
            findAfter(edge.relV);
          }
        } else {
          if (activeNodeItemIds.findIndex(t => t === edge.tgtNodeItemId) === -1) {
            activeNodeItemIds.push(edge.tgtNodeItemId);
            findAfter(edge.tgtNodeItemId);
          }
        }
        
      }
    }
  };

  findBefore(activeItemId);
  findAfter(activeItemId);

  return {
    activeNodeItemIds,
    activeEdgeIds
  };
};
