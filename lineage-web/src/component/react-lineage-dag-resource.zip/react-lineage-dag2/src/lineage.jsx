import React, {useState, useEffect, useRef} from 'react';
import _ from 'lodash';
import PropTypes from 'prop-types';
import ReactButterfly from 'butterfly-react';

import dagreLayout from './util/layout';
import focusNode from './util/focus_node';
import {NodeTypes, EdgeTypes} from './util/props';
import {toNodes, toEdges, toNodesItem, toEdgesItem, getActiveThings, getItemActiveThings} from './util/util';

import './index.less';

const defaultOptions = {
  theme: {
    edge: {
      // arrow: true,
      // arrowPosition: 0.1,
      // arrowOffset: 0.0,
      // isExpandWidth: true,
    }
  }
};

const constOption = {
  disLinkable: false, // 可删除连线
  linkable: false, // 可连线
  draggable: true, // 可拖动
  zoomable: true, // 可放大
  moveable: true, // 可平移
  ranker: 'tight-tree',
};

const noop = () => null;
let baseZIndex = 10;

const LineageDag = (props) => {
  const {
    nodes = [], edges = [], onNodeDoubleClick = noop,
    onNodeItemDoubleClick = noop, onLoaded = noop, layout = {},
    onEndpointClick = noop,
    onItemClick = noop,
    isLoop = false,
    loopNum = 0,
  } = props;
  const canvasRef = useRef(null);
  const [btfEdges, setBtfEdges] = useState([]);
  const [btfNodes, setBtfNodes] = useState([]);
  const [relayout, setRelayout] = useState(false);
  const options = _.merge(
    {},
    defaultOptions,
    constOption,
    props.options,
    {
      // layout: 'ForceLayout'
      layout: dagreLayout({
        ranksep: layout.ranksep,
        nodesep: layout.nodesep,
      }),
    }
  );

  // 画布初始化
  const onCvsLoaded = (canvas) => {
    canvasRef.current = canvas;
    onLoaded(canvas);

    canvas.focusNode = (nodeId, options) => {
      const node = canvas.getNode(nodeId);
      focusNode(node, options, canvas);
    };
    
    canvas.setZoomable(true, true)

    

    setTimeout(() => {
      canvas.relayout();
      canvas.focusCenterWithAnimate();

      // 设置缩略图
      canvas.setMinimap(true, {
        nodeColor: '#2466ff',
        groupColor: '#2466ff',
        containerStyle: {
          height: '100px',
          background: '#f8f9ff',
          left: '0px',
          bottom: '0px',
          border: '1px solid rgb(221 221 221 / 63%)',
          boxShadow: '0px 0px 7px #726d6d21',
        },
        viewportStyle: {
          background: 'rgb(128 204 247 / 21%)',
          // border: '2px solid rgb(43, 102, 255)',
        },
      })
    }, 100);
  };

  /**
   * 响应边和item的高亮事件
   * @param {String} itemId item的id
   */
  const onItemActive = _.debounce((itemId) => {
    const canvas = canvasRef.current;
    const {activeEdgeIds, activeNodeItemIds} = getActiveThings({
      edges,
      nodes,
      activeItemId: itemId
    });
    setBtfNodes(
      toNodesItem(
        {
          ...nodeOptions,
          activeNodeItemIds,
          onEndpointClick,
        }
      )
    );

    const btfEdges = toEdgesItem(
      {
        ...edgeOptions,
        activeEdgeIds,
      }
    );

    const activeEdges = [];
    btfEdges.forEach(edge => {
      const edgeId = edge.id;
      if (edge.isActive) {
        const e = canvas.getEdge(edgeId);
        if (e) {
          activeEdges.push(e);
        }
      }
    });

    canvas.setEdgeZIndex(activeEdges, baseZIndex);
    baseZIndex++;
    setBtfEdges(btfEdges);
  }, 100);

    /**
   * 响应边和item的高亮事件
   * @param {String} itemId item的id
   */
     const onNodeClick = _.debounce((itemId) => {
      const canvas = canvasRef.current;
      const {activeEdgeIds, activeNodeItemIds} = getItemActiveThings({
        edges,
        nodes,
        activeItemId: itemId
      });

      setBtfNodes(
        toNodes(
          {
            ...nodeOptions,
            activeNodeItemIds,
            onEndpointClick,
          }
        )
      );
      const btfEdges = toEdges(
        {
          ...edgeOptions,
          activeEdgeIds
        }
      );
      const activeEdges = [];
      btfEdges.forEach(edge => {
        const edgeId = edge.id;
        if (edge.isActive) {
          const e = canvas.getEdge(edgeId);
          if (e) {
            activeEdges.push(e);
          }
        }
      });
  
      canvas.setEdgeZIndex(activeEdges, baseZIndex);
      baseZIndex++;
      setBtfEdges(btfEdges);
    }, 100);

  /**
   * 节点展开收起逻辑
   *   收起某一个节点时：
   *    1. 只收起当前节点
   *   展开某一个节点时：
   *    1. 一个节点展开时，其他两侧的节点也需要展开
   *    2. 一个节点展开时，我们只计算他的item的边，收起只计算他的node的边
   */
  const nodeOptions = {
    nodes,
    edges,
    onItemActive,
    onNodeClick,
    onItemClick,
    onNodeDoubleClick,
    onNodeItemDoubleClick,
    onEndpointClick,
    isLoop,
    loopNum,
  };

  const edgeOptions = {
    edges,
    nodes,
  };

  useEffect(() => {
    if (nodes.length === 0) {
      return;
    }
    setBtfNodes(toNodes(nodeOptions));
    setBtfEdges(toEdges(edgeOptions));
  }, [nodes, edges, nodes.length, edges.length]);

  useEffect(() => {
    if (!canvasRef.current) {
      return;
    }

    setRelayout(true);

  }, [nodes, edges.length]);

  if (nodes.length === 0 || btfNodes.length === 0) {
    return null;
  }

  return (
    <div className="lineage_dag">
      <ReactButterfly
        nodes={btfNodes}
        edges={btfEdges}
        options={options}
        onLoaded={onCvsLoaded}
        onEachFrame={() => {
          if (relayout) {
            canvasRef.current.relayout();
            setRelayout(false);
          }

          props.onEachFrame();
        }}
      />
    </div>
  );
};

LineageDag.propTypes = {
  options: PropTypes.object,                // 小蝴蝶画布属性，参考：https://github.com/alibaba/butterfly/blob/master/docs/zh-CN/canvas.md#%E5%B1%9E%E6%80%A7
  layout: {
    ranksep: PropTypes.number,
    radius: PropTypes.number
  },
  nodes: PropTypes.arrayOf(NodeTypes),      // 节点
  edges: PropTypes.arrayOf(EdgeTypes),      // 边类型
  onNodeDoubleClick: PropTypes.func,        // 双击某个节点
  onNodeItemDoubleClick: PropTypes.func,    // 双击某个字段
  onLoaded: PropTypes.func,                 // 小蝴蝶加载完时调用
  onEachFrame: PropTypes.func,              // 每一帧画完之后
  onEndpointClick: PropTypes.func,          // 锚点单击事件
  isLoop: PropTypes.boolean,
  loopNum: PropTypes.number,
};

export default LineageDag;

